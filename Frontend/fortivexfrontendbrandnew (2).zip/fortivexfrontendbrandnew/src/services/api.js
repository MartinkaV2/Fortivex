import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:8000/api', // Módosítsd a backend URL-re
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor - token hozzáadása
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor - hibakezelés
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      window.location.href = '/';
    }
    return Promise.reject(error);
  }
);

// Auth endpoints
export const authAPI = {
  login: (credentials) => api.post('/auth/login', credentials),
  register: (userData) => api.post('/auth/register', userData),
  logout: () => api.post('/auth/logout'),
  getCurrentUser: () => api.get('/auth/me'),
};

// Player endpoints
export const playerAPI = {
  getStats: (playerId) => api.get(`/players/${playerId}/stats`),
  updateStats: (playerId, stats) => api.patch(`/players/${playerId}/stats`, stats),
  getProgress: (playerId) => api.get(`/players/${playerId}/progress`),
};

// Admin endpoints
export const adminAPI = {
  getAllPlayers: () => api.get('/admin/players'),
  getPlayerById: (playerId) => api.get(`/admin/players/${playerId}`),
  updatePlayer: (playerId, data) => api.patch(`/admin/players/${playerId}`, data),
  deletePlayer: (playerId) => api.delete(`/admin/players/${playerId}`),
  getAllStats: () => api.get('/admin/stats'),
};

// Game data endpoints
export const gameAPI = {
  getMaps: () => api.get('/game/maps'),
  getEnemies: () => api.get('/game/enemies'),
};

export default api;