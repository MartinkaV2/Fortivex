<template>
  <div class="home-page">
    <Navbar />
    
    <main class="main-content">

    <section class="hero-section">
      <div class="hero-content">
        <h1 class="hero-title">FORTIVEX PROJEKT</h1>
        <p class="hero-subtitle">Védd meg a váradat a sötétség erőitől!</p>
        <div class="hero-buttons">
          <button class="cta-button primary">Játék Letöltése</button>
          <button class="cta-button secondary" @click="scrollToSection('description')">
            Tudj meg többet
          </button>
        </div>
      </div>
    </section>

    <GameDescription />
    <MapsList />
    <EnemiesList />

    <section id="contact" class="contact-section">
      <div class="container">
        <h2 class="section-title">Elérhetőségek</h2>
        <div class="contact-content">
          <div class="contact-info">
            <div class="contact-item">
              <span class="contact-icon">📧</span>
              <div>
                <h4>Email</h4>
                <p>support@fortivex.com</p>
              </div>
            </div>
            <div class="contact-item">
              <span class="contact-icon">🌐</span>
              <div>
                <h4>Weboldal</h4>
                <p>www.fortivex.com</p>
              </div>
            </div>
            <div class="contact-item">
              <span class="contact-icon">💬</span>
              <div>
                <h4>Discord</h4>
                <p>discord.gg/fortivex</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    </main>

    <Footer />
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Navbar from '@/components/common/Navbar.vue';
import Footer from '@/components/common/Footer.vue';
import GameDescription from '@/components/home/GameDescription.vue';
import MapsList from '@/components/home/MapsList.vue';
import EnemiesList from '@/components/home/EnemiesList.vue';

const scrollToSection = (sectionId) => {
  const element = document.getElementById(sectionId);
  if (element) {
    element.scrollIntoView({ behavior: 'smooth' });
  }
};
</script>

<style scoped lang="scss">
.home-page {
  min-height: 100vh;
  background: linear-gradient(135deg, #1a0f0a 0%, #2c1810 100%);
}

.hero-section {
  height: calc(100vh - 80px);
  display: flex;
  align-items: center;
  justify-content: center;
  background: 
    linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)),
    url('/hero-bg.jpg') center/cover;
  text-align: center;
  padding: 2rem;
}

.hero-content {
  max-width: 800px;
}

.hero-title {
  font-size: 4rem;
  color: #ffd700;
  font-family: 'Cinzel', serif;
  text-shadow: 4px 4px 8px rgba(0, 0, 0, 0.9);
  margin-bottom: 1rem;
  animation: fadeInUp 1s ease;
}

.hero-subtitle {
  font-size: 1.5rem;
  color: #f4e4c1;
  margin-bottom: 2rem;
  animation: fadeInUp 1s ease 0.2s both;
}

.hero-buttons {
  display: flex;
  gap: 1rem;
  justify-content: center;
  animation: fadeInUp 1s ease 0.4s both;
}

.cta-button {
  padding: 1rem 2rem;
  font-size: 1.1rem;
  font-weight: 700;
  border: 2px solid #ffd700;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.3s ease;

  &.primary {
    background: #8b4513;
    color: #fff;

    &:hover {
      background: #a0522d;
      transform: translateY(-3px);
      box-shadow: 0 8px 20px rgba(255, 215, 0, 0.4);
    }
  }

  &.secondary {
    background: transparent;
    color: #ffd700;

    &:hover {
      background: rgba(255, 215, 0, 0.1);
      transform: translateY(-3px);
    }
  }
}

@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(30px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.contact-section {
  padding: 5rem 0;
  background: #1a0f0a;
}

.contact-content {
  max-width: 600px;
  margin: 0 auto;
}

.contact-info {
  display: flex;
  flex-direction: column;
  gap: 2rem;
}

.contact-item {
  display: flex;
  align-items: center;
  gap: 1.5rem;
  background: #2c1810;
  padding: 1.5rem;
  border: 2px solid #8b4513;
  border-radius: 12px;

  .contact-icon {
    font-size: 2.5rem;
  }

  h4 {
    color: #ffd700;
    font-size: 1.2rem;
    margin-bottom: 0.3rem;
  }

  p {
    color: #f4e4c1;
  }
}

.main-content {
  flex: 1;
}

@media (max-width: 768px) {
  .hero-title {
    font-size: 2.5rem;
  }

  .description-content {
    grid-template-columns: 1fr;
  }

  .hero-buttons {
    flex-direction: column;
  }
}
</style>