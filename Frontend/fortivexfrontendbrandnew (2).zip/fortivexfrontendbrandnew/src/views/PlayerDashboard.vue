<template>
  <div class="player-dashboard">
    <Navbar />

    <div class="dashboard-container">
      <div class="welcome-section">
        <h1 class="welcome-title">Üdvözöllek, {{ user?.username }}!</h1>
        <p class="welcome-subtitle">Itt követheted nyomon fejlődésed és statisztikáidat</p>
      </div>

      <div v-if="loading" class="loading">
        <div class="spinner"></div>
        <p>Betöltés...</p>
      </div>

      <div v-else-if="error" class="error-box">
        <p>{{ error }}</p>
        <button @click="loadPlayerData" class="retry-button">Újrapróbálás</button>
      </div>

      <div v-else class="stats-grid">
        <!-- Összesített statisztikák -->
        <div class="stat-card highlight">
          <div class="stat-icon">🏆</div>
          <div class="stat-content">
            <h3>Szint</h3>
            <p class="stat-value">{{ stats?.level || 1 }}</p>
            <div class="progress-bar">
              <div class="progress-fill" :style="{ width: `${xpProgress}%` }"></div>
            </div>
            <p class="stat-detail">{{ stats?.currentXp || 0 }} / {{ stats?.nextLevelXp || 100 }} XP</p>
          </div>
        </div>

        <div class="stat-card">
          <div class="stat-icon">⚔️</div>
          <div class="stat-content">
            <h3>Győzelmek</h3>
            <p class="stat-value">{{ stats?.wins || 0 }}</p>
            <p class="stat-detail">Összes menet: {{ stats?.totalGames || 0 }}</p>
          </div>
        </div>

        <div class="stat-card">
          <div class="stat-icon">💰</div>
          <div class="stat-content">
            <h3>Összegyűjtött Arany</h3>
            <p class="stat-value">{{ formatNumber(stats?.totalGold) }}</p>
            <p class="stat-detail">Jelenlegi: {{ formatNumber(stats?.currentGold) }}</p>
          </div>
        </div>

        <div class="stat-card">
          <div class="stat-icon">💀</div>
          <div class="stat-content">
            <h3>Legyőzött Ellenségek</h3>
            <p class="stat-value">{{ formatNumber(stats?.enemiesKilled) }}</p>
            <p class="stat-detail">Rekord hullám: {{ stats?.maxWaveReached || 0 }}</p>
          </div>
        </div>

        <!-- Pálya haladás -->
        <div class="maps-progress-card">
          <h2 class="card-title">Pálya Haladás</h2>
          <div class="maps-list">
            <div
              v-for="map in progress?.maps || []"
              :key="map.id"
              class="map-progress-item"
            >
              <div class="map-header">
                <h4>{{ map.name }}</h4>
                <span class="completion-badge" :class="map.completed ? 'completed' : 'incomplete'">
                  {{ map.completed ? '✓ Teljesítve' : 'Folyamatban' }}
                </span>
              </div>
              <div class="map-stats">
                <span>Legjobb idő: {{ formatTime(map.bestTime) }}</span>
                <span>Csillagok: {{ map.stars }}/3 ⭐</span>
              </div>
              <div class="progress-bar">
                <div class="progress-fill" :style="{ width: `${map.completionPercent}%` }"></div>
              </div>
            </div>
          </div>
        </div>

        <!-- Teljesítmények -->
        <div class="achievements-card">
          <h2 class="card-title">Teljesítmények</h2>
          <div class="achievements-grid">
            <div
              v-for="achievement in progress?.achievements || []"
              :key="achievement.id"
              class="achievement-item"
              :class="{ unlocked: achievement.unlocked }"
            >
              <div class="achievement-icon">{{ achievement.icon }}</div>
              <div class="achievement-info">
                <h4>{{ achievement.name }}</h4>
                <p>{{ achievement.description }}</p>
              </div>
              <div v-if="achievement.unlocked" class="achievement-badge">✓</div>
            </div>
          </div>
        </div>

        <!-- Játék történet -->
        <div class="history-card">
          <h2 class="card-title">Utolsó Játékok</h2>
          <div class="history-list">
            <div
              v-for="game in stats?.recentGames || []"
              :key="game.id"
              class="history-item"
            >
              <div class="game-result" :class="game.won ? 'win' : 'loss'">
                {{ game.won ? '🏆 Győzelem' : '💀 Vereség' }}
              </div>
              <div class="game-details">
                <p><strong>{{ game.mapName }}</strong></p>
                <p>Hullám: {{ game.waveReached }} | Idő: {{ formatTime(game.duration) }}</p>
                <p class="game-date">{{ formatDate(game.playedAt) }}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue';
import { useAuthStore } from '@/stores/auth';
import { usePlayerStore } from '@/stores/player';
import Navbar from '@/components/common/Navbar.vue';

const authStore = useAuthStore();
const playerStore = usePlayerStore();

const user = computed(() => authStore.user);
const stats = computed(() => playerStore.stats);
const progress = computed(() => playerStore.progress);
const loading = computed(() => playerStore.loading);
const error = computed(() => playerStore.error);

const xpProgress = computed(() => {
  if (!stats.value) return 0;
  const current = stats.value.currentXp || 0;
  const needed = stats.value.nextLevelXp || 100;
  return Math.min((current / needed) * 100, 100);
});

const formatNumber = (num) => {
  if (!num) return '0';
  return num.toLocaleString('hu-HU');
};

const formatTime = (seconds) => {
  if (!seconds) return '0:00';
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}:${secs.toString().padStart(2, '0')}`;
};

const formatDate = (dateString) => {
  if (!dateString) return '';
  const date = new Date(dateString);
  return date.toLocaleDateString('hu-HU', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
};

const loadPlayerData = async () => {
  if (user.value?.id) {
    await Promise.all([
      playerStore.fetchStats(user.value.id),
      playerStore.fetchProgress(user.value.id),
    ]);
  }
};

onMounted(() => {
  loadPlayerData();
});
</script>

<style scoped lang="scss">
.player-dashboard {
  min-height: 100vh;
  background: linear-gradient(135deg, #1a0f0a 0%, #2c1810 100%);
}

.dashboard-container {
  max-width: 1400px;
  margin: 0 auto;
  padding: 2rem;
}

.welcome-section {
  text-align: center;
  margin-bottom: 3rem;
}

.welcome-title {
  font-size: 3rem;
  color: #ffd700;
  font-family: 'Cinzel', serif;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.8);
  margin-bottom: 0.5rem;
}

.welcome-subtitle {
  color: #f4e4c1;
  font-size: 1.2rem;
}

.loading {
  text-align: center;
  padding: 4rem;

  .spinner {
    width: 60px;
    height: 60px;
    border: 4px solid rgba(255, 215, 0, 0.3);
    border-top-color: #ffd700;
    border-radius: 50%;
    animation: spin 1s linear infinite;
    margin: 0 auto 1rem;
  }

  p {
    color: #f4e4c1;
    font-size: 1.2rem;
  }
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

.error-box {
  background: rgba(220, 20, 60, 0.2);
  border: 2px solid #dc143c;
  color: #ff6b6b;
  padding: 2rem;
  border-radius: 12px;
  text-align: center;

  .retry-button {
    margin-top: 1rem;
    padding: 0.8rem 1.5rem;
    background: #8b4513;
    color: #fff;
    border: 2px solid #ffd700;
    border-radius: 8px;
    cursor: pointer;
    font-weight: 600;
    transition: all 0.3s ease;

    &:hover {
      background: #a0522d;
      transform: translateY(-2px);
    }
  }
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 2rem;
}

.stat-card {
  background: #2c1810;
  border: 2px solid #8b4513;
  border-radius: 12px;
  padding: 1.5rem;
  display: flex;
  align-items: center;
  gap: 1.5rem;
  transition: all 0.3s ease;

  &:hover {
    transform: translateY(-5px);
    border-color: #ffd700;
    box-shadow: 0 10px 30px rgba(255, 215, 0, 0.3);
  }

  &.highlight {
    border-color: #ffd700;
    background: linear-gradient(135deg, #3d2517 0%, #5c3a25 100%);
  }

  .stat-icon {
    font-size: 3rem;
  }

  .stat-content {
    flex: 1;

    h3 {
      color: #f4e4c1;
      font-size: 0.9rem;
      margin-bottom: 0.5rem;
      text-transform: uppercase;
      letter-spacing: 1px;
    }

    .stat-value {
      color: #ffd700;
      font-size: 2rem;
      font-weight: 700;
      margin-bottom: 0.5rem;
    }

    .stat-detail {
      color: rgba(244, 228, 193, 0.7);
      font-size: 0.85rem;
    }
  }
}

.progress-bar {
  width: 100%;
  height: 8px;
  background: #1a0f0a;
  border-radius: 4px;
  overflow: hidden;
  margin: 0.5rem 0;

  .progress-fill {
    height: 100%;
    background: linear-gradient(90deg, #ffd700, #ffed4e);
    transition: width 0.5s ease;
  }
}

.maps-progress-card,
.achievements-card,
.history-card {
  grid-column: 1 / -1;
  background: #2c1810;
  border: 2px solid #8b4513;
  border-radius: 12px;
  padding: 2rem;
}

.card-title {
  color: #ffd700;
  font-size: 1.8rem;
  margin-bottom: 1.5rem;
  font-family: 'Cinzel', serif;
}

.maps-list {
  display: grid;
  gap: 1.5rem;
}

.map-progress-item {
  background: #1a0f0a;
  padding: 1.5rem;
  border-radius: 8px;
  border: 1px solid #8b4513;

  .map-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;

    h4 {
      color: #ffd700;
      font-size: 1.2rem;
    }

    .completion-badge {
      padding: 0.3rem 0.8rem;
      border-radius: 12px;
      font-size: 0.85rem;
      font-weight: 600;

      &.completed {
        background: rgba(50, 205, 50, 0.2);
        color: #32cd32;
        border: 1px solid #32cd32;
      }

      &.incomplete {
        background: rgba(255, 165, 0, 0.2);
        color: #ffa500;
        border: 1px solid #ffa500;
      }
    }
  }

  .map-stats {
    display: flex;
    gap: 2rem;
    margin-bottom: 1rem;
    color: #f4e4c1;
    font-size: 0.9rem;
  }
}

.achievements-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  gap: 1rem;
}

.achievement-item {
  background: #1a0f0a;
  padding: 1rem;
  border-radius: 8px;
  border: 2px solid #8b4513;
  display: flex;
  align-items: center;
  gap: 1rem;
  opacity: 0.5;
  position: relative;

  &.unlocked {
    opacity: 1;
    border-color: #ffd700;
  }

  .achievement-icon {
    font-size: 2.5rem;
  }

  .achievement-info {
    flex: 1;

    h4 {
      color: #ffd700;
      font-size: 1rem;
      margin-bottom: 0.3rem;
    }

    p {
      color: #f4e4c1;
      font-size: 0.85rem;
    }
  }

  .achievement-badge {
    position: absolute;
    top: 0.5rem;
    right: 0.5rem;
    color: #32cd32;
    font-size: 1.5rem;
  }
}

.history-list {
  display: grid;
  gap: 1rem;
}

.history-item {
  background: #1a0f0a;
  padding: 1rem;
  border-radius: 8px;
  border: 1px solid #8b4513;
  display: flex;
  gap: 1rem;
  align-items: center;

  .game-result {
    padding: 0.5rem 1rem;
    border-radius: 8px;
    font-weight: 700;
    white-space: nowrap;

    &.win {
      background: rgba(50, 205, 50, 0.2);
      color: #32cd32;
      border: 1px solid #32cd32;
    }

    &.loss {
      background: rgba(220, 20, 60, 0.2);
      color: #ff6b6b;
      border: 1px solid #dc143c;
    }
  }

  .game-details {
    flex: 1;

    p {
      color: #f4e4c1;
      font-size: 0.9rem;
      margin-bottom: 0.3rem;
    }

    .game-date {
      color: rgba(244, 228, 193, 0.6);
      font-size: 0.8rem;
    }
  }
}

@media (max-width: 768px) {
  .welcome-title {
    font-size: 2rem;
  }

  .stats-grid {
    grid-template-columns: 1fr;
  }
}
</style>