import { defineStore } from 'pinia';
import { ref } from 'vue';
import { adminAPI } from '@/services/api';

export const useAdminStore = defineStore('admin', () => {
  const players = ref([]);
  const allStats = ref(null);
  const selectedPlayer = ref(null);
  const loading = ref(false);
  const error = ref(null);

  async function fetchAllPlayers() {
    loading.value = true;
    error.value = null;
    try {
      const response = await adminAPI.getAllPlayers();
      players.value = response.data;
    } catch (err) {
      error.value = err.response?.data?.message || 'Hiba a játékosok betöltésekor';
    } finally {
      loading.value = false;
    }
  }

  async function fetchPlayerById(playerId) {
    loading.value = true;
    error.value = null;
    try {
      const response = await adminAPI.getPlayerById(playerId);
      selectedPlayer.value = response.data;
    } catch (err) {
      error.value = err.response?.data?.message || 'Hiba a játékos betöltésekor';
    } finally {
      loading.value = false;
    }
  }

  async function updatePlayer(playerId, data) {
    loading.value = true;
    error.value = null;
    try {
      const response = await adminAPI.updatePlayer(playerId, data);
      // Frissítjük a listában is
      const index = players.value.findIndex(p => p.id === playerId);
      if (index !== -1) {
        players.value[index] = response.data;
      }
      return true;
    } catch (err) {
      error.value = err.response?.data?.message || 'Hiba a játékos frissítésekor';
      return false;
    } finally {
      loading.value = false;
    }
  }

  async function deletePlayer(playerId) {
    loading.value = true;
    error.value = null;
    try {
      await adminAPI.deletePlayer(playerId);
      players.value = players.value.filter(p => p.id !== playerId);
      return true;
    } catch (err) {
      error.value = err.response?.data?.message || 'Hiba a játékos törlésekor';
      return false;
    } finally {
      loading.value = false;
    }
  }

  async function fetchAllStats() {
    loading.value = true;
    error.value = null;
    try {
      const response = await adminAPI.getAllStats();
      allStats.value = response.data;
    } catch (err) {
      error.value = err.response?.data?.message || 'Hiba a statisztikák betöltésekor';
    } finally {
      loading.value = false;
    }
  }

  return {
    players,
    allStats,
    selectedPlayer,
    loading,
    error,
    fetchAllPlayers,
    fetchPlayerById,
    updatePlayer,
    deletePlayer,
    fetchAllStats,
  };
});