import { defineStore } from 'pinia';
import { ref, computed } from 'vue';
import { authAPI } from '@/services/api';

export const useAuthStore = defineStore('auth', () => {
  const user = ref(null);
  const token = ref(localStorage.getItem('token') || null);
  const loading = ref(false);
  const error = ref(null);

  const isAuthenticated = computed(() => !!token.value);
  const isAdmin = computed(() => user.value?.role === 'admin');
  const isPlayer = computed(() => user.value?.role === 'player');

  async function login(credentials) {
    loading.value = true;
    error.value = null;
    try {
      const response = await authAPI.login(credentials);
      token.value = response.data.token;
      user.value = response.data.user;
      localStorage.setItem('token', token.value);
      return true;
    } catch (err) {
      error.value = err.response?.data?.message || 'Bejelentkezési hiba';
      return false;
    } finally {
      loading.value = false;
    }
  }

  async function register(userData) {
    loading.value = true;
    error.value = null;
    try {
      const response = await authAPI.register(userData);
      token.value = response.data.token;
      user.value = response.data.user;
      localStorage.setItem('token', token.value);
      return true;
    } catch (err) {
      error.value = err.response?.data?.message || 'Regisztrációs hiba';
      return false;
    } finally {
      loading.value = false;
    }
  }

  async function logout() {
    try {
      await authAPI.logout();
    } catch (err) {
      console.error('Logout error:', err);
    } finally {
      user.value = null;
      token.value = null;
      localStorage.removeItem('token');
    }
  }

  async function fetchCurrentUser() {
    if (!token.value) return;
    
    loading.value = true;
    try {
      const response = await authAPI.getCurrentUser();
      user.value = response.data;
    } catch (err) {
      console.error('Fetch user error:', err);
      logout();
    } finally {
      loading.value = false;
    }
  }

  return {
    user,
    token,
    loading,
    error,
    isAuthenticated,
    isAdmin,
    isPlayer,
    login,
    register,
    logout,
    fetchCurrentUser,
  };
});