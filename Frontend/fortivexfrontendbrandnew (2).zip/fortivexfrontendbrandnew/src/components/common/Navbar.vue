<template>
  <nav class="navbar">
    <div class="navbar-container">
      <div class="navbar-logo">
        <router-link to="/">
          <img src="@/assets/images/logo.png" alt="Fortivex Logo" class="logo" />
          <span class="game-title">FORTIVEX PROJEKT</span>
        </router-link>
      </div>

      <div class="navbar-menu">
        <router-link to="/" class="nav-link">Főoldal</router-link>
        
        <template v-if="isAuthenticated">
          <router-link v-if="isPlayer" to="/player" class="nav-link">
            Profil
          </router-link>
          <router-link v-if="isAdmin" to="/admin" class="nav-link">
            Admin Panel
          </router-link>
        </template>
      </div>

      <div class="navbar-auth">
        <template v-if="!isAuthenticated">
          <div class="auth-dropdown">
            <button @click="toggleDropdown" class="auth-button">
              <span>Bejelentkezés / Regisztráció</span>
              <span class="arrow" :class="{ open: dropdownOpen }">▼</span>
            </button>
            
            <div v-if="dropdownOpen" class="dropdown-menu">
              <button @click="showLogin" class="dropdown-item">Bejelentkezés</button>
              <button @click="showRegister" class="dropdown-item">Regisztráció</button>
            </div>
          </div>
        </template>
        
        <template v-else>
          <div class="user-info">
            <span class="username">{{ user?.username }}</span>
            <button @click="handleLogout" class="logout-button">Kijelentkezés</button>
          </div>
        </template>
      </div>
    </div>

    <LoginModal v-if="loginModalOpen" @close="loginModalOpen = false" />
    <RegisterModal v-if="registerModalOpen" @close="registerModalOpen = false" />
  </nav>
</template>

<script setup>
import { ref, computed } from 'vue';
import { useAuthStore } from '@/stores/auth';
import { useRouter } from 'vue-router';
import LoginModal from '@/components/auth/LoginModal.vue';
import RegisterModal from '@/components/auth/RegisterModal.vue';

const authStore = useAuthStore();
const router = useRouter();

const dropdownOpen = ref(false);
const loginModalOpen = ref(false);
const registerModalOpen = ref(false);

const isAuthenticated = computed(() => authStore.isAuthenticated);
const isPlayer = computed(() => authStore.isPlayer);
const isAdmin = computed(() => authStore.isAdmin);
const user = computed(() => authStore.user);

const toggleDropdown = () => {
  dropdownOpen.value = !dropdownOpen.value;
};

const showLogin = () => {
  dropdownOpen.value = false;
  loginModalOpen.value = true;
};

const showRegister = () => {
  dropdownOpen.value = false;
  registerModalOpen.value = true;
};

const handleLogout = async () => {
  await authStore.logout();
  router.push('/');
};
</script>

<style scoped lang="scss">
.navbar {
  background: linear-gradient(135deg, #2c1810 0%, #4a2c1a 100%);
  padding: 1rem 2rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.3);
  position: sticky;
  top: 0;
  z-index: 100;
  border-bottom: 3px solid #8b4513;
}

.navbar-container {
  max-width: 1400px;
  margin: 0 auto;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.navbar-logo {
  a {
    display: flex;
    align-items: center;
    text-decoration: none;
    gap: 1rem;
  }

  .logo {
    height: 50px;
    width: auto;
  }

  .game-title {
    font-size: 1.5rem;
    font-weight: bold;
    color: #ffd700;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.8);
    font-family: 'Cinzel', serif;
  }
}

.navbar-menu {
  display: flex;
  gap: 2rem;

  .nav-link {
    color: #f4e4c1;
    text-decoration: none;
    font-size: 1.1rem;
    font-weight: 500;
    padding: 0.5rem 1rem;
    border-radius: 8px;
    transition: all 0.3s ease;

    &:hover {
      background: rgba(255, 215, 0, 0.1);
      color: #ffd700;
    }

    &.router-link-active {
      color: #ffd700;
      background: rgba(255, 215, 0, 0.2);
    }
  }
}

.navbar-auth {
  .auth-dropdown {
    position: relative;

    .auth-button {
      background: #8b4513;
      color: #fff;
      border: 2px solid #ffd700;
      padding: 0.6rem 1.2rem;
      border-radius: 8px;
      cursor: pointer;
      font-size: 1rem;
      font-weight: 600;
      display: flex;
      align-items: center;
      gap: 0.5rem;
      transition: all 0.3s ease;

      &:hover {
        background: #a0522d;
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
      }

      .arrow {
        transition: transform 0.3s ease;

        &.open {
          transform: rotate(180deg);
        }
      }
    }

    .dropdown-menu {
      position: absolute;
      top: calc(100% + 0.5rem);
      right: 0;
      background: #3d2517;
      border: 2px solid #ffd700;
      border-radius: 8px;
      min-width: 200px;
      box-shadow: 0 8px 16px rgba(0, 0, 0, 0.4);
      overflow: hidden;

      .dropdown-item {
        display: block;
        width: 100%;
        padding: 0.8rem 1.2rem;
        background: transparent;
        color: #f4e4c1;
        border: none;
        text-align: left;
        cursor: pointer;
        font-size: 1rem;
        transition: all 0.2s ease;

        &:hover {
          background: #8b4513;
          color: #ffd700;
        }

        &:not(:last-child) {
          border-bottom: 1px solid rgba(255, 215, 0, 0.2);
        }
      }
    }
  }

  .user-info {
    display: flex;
    align-items: center;
    gap: 1rem;

    .username {
      color: #ffd700;
      font-weight: 600;
      font-size: 1.1rem;
    }

    .logout-button {
      background: #8b4513;
      color: #fff;
      border: 2px solid #ffd700;
      padding: 0.5rem 1rem;
      border-radius: 8px;
      cursor: pointer;
      font-weight: 600;
      transition: all 0.3s ease;

      &:hover {
        background: #a0522d;
        transform: translateY(-2px);
      }
    }
  }
}

@media (max-width: 768px) {
  .navbar-container {
    flex-direction: column;
    gap: 1rem;
  }

  .navbar-menu {
    gap: 1rem;
  }
}
</style>