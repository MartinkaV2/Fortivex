// src/api.js
import axios from "axios";


// Közvetlen backend API hívás (CORS a backendenben engedélyezve van)
const api = axios.create({
  baseURL: "http://localhost:5105/api",
  timeout: 15000,
  withCredentials: false
})

// Request interceptor: attach Authorization header when token exists in localStorage
api.interceptors.request.use(config => {
  try {
    const token = localStorage.getItem('token')
    if (token) {
      config.headers = config.headers || {}
      config.headers['Authorization'] = `Bearer ${token}`
    }
  } catch (e) {
    // ignore localStorage errors
  }
  return config
}, error => Promise.reject(error))

// Response interceptor: retry on network/timeout errors
api.interceptors.response.use(
  response => response,
  async error => {
    const config = error.config
    
    // Initialize retry count if not set
    if (!config.retryCount) {
      config.retryCount = 0
    }
    
    const maxRetries = 3
    const isNetworkError = !error.response || error.code === 'ECONNABORTED' || error.code === 'ECONNRESET' || error.code === 'ETIMEDOUT'
    const isNetworkMessage = error.message?.toLowerCase().includes('network') || error.message?.toLowerCase().includes('timeout')
    
    console.error('🔴 API Error:', {
      status: error.response?.status,
      message: error.message,
      code: error.code,
      url: config?.url,
      isNetworkError,
      isNetworkMessage,
      retryCount: config.retryCount
    })
    
    // Retry only on network/timeout errors, not on HTTP errors (4xx, 5xx)
    if ((isNetworkError || isNetworkMessage) && config.retryCount < maxRetries) {
      config.retryCount++
      const delayMs = 200 * config.retryCount // exponential backoff: 200ms, 400ms, 600ms
      
      console.warn(`Network error detected. Retrying (${config.retryCount}/${maxRetries}) after ${delayMs}ms...`, error.message)
      
      // Wait before retrying
      await new Promise(resolve => setTimeout(resolve, delayMs))
      
      // Retry the request
      return api(config)
    }
    
    // Give up after max retries or if not a network error
    return Promise.reject(error)
  }
)

export default api
