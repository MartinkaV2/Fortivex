// Simple test script to verify API connection
import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:5105/api',
  timeout: 15000,
  withCredentials: true
});

async function testLogin() {
  console.log('🧪 Testing API connection to http://localhost:5105/api');
  
  try {
    // Test 1: Check if API is reachable
    console.log('\n📍 Test 1: Checking if backend is reachable...');
    try {
      const healthCheck = await axios.get('http://localhost:5105/api/accounts', { timeout: 5000 });
      console.log('✅ Backend is reachable!', healthCheck.status);
    } catch (e) {
      console.warn('⚠️  GET /accounts failed (expected if auth required):', e.message);
    }

    // Test 2: Attempt login
    console.log('\n📍 Test 2: Attempting login...');
    const loginPayload = {
      UserName: 'xyz123',
      PasswordHash: 'teszt123'
    };
    
    console.log('Sending:', loginPayload);
    
    try {
      const response = await api.post('accounts/login', loginPayload);
      console.log('✅ Login successful!');
      console.log('Response:', response.data);
      return response.data;
    } catch (error) {
      console.error('❌ Login failed:');
      console.error('Message:', error.message);
      console.error('Status:', error.response?.status);
      console.error('Data:', error.response?.data);
      console.error('Config:', {
        url: error.config?.url,
        method: error.config?.method,
        baseURL: error.config?.baseURL
      });
      throw error;
    }
  } catch (error) {
    console.error('\n❌ Test failed:', error.message);
    process.exit(1);
  }
}

// Run the test
testLogin();
