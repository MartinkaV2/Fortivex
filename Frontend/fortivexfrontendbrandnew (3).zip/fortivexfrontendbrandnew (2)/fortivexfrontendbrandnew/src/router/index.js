// src/router/index.js
import { createRouter, createWebHistory } from 'vue-router';
import { useAuthStore } from '@/stores/auth';

const routes = [
  {
    path: '/',
    name: 'Home',
    component: () => import('@/views/HomePage.vue'),
  },
  {
    path: '/test',
    name: 'Test',
    component: () => import('@/components/SimpleTestPage.vue'),
  },
  {
    path: '/player',
    name: 'PlayerDashboard',
    component: () => import('@/views/PlayerDashboard.vue'),
    meta: { requiresAuth: true, role: 'player' },
  },
  {
    path: '/admin',
    name: 'AdminDashboard',
    component: () => import('@/views/AdminDashboard.vue'),
    meta: { requiresAuth: true, role: 'admin' },
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

// Navigation guards
router.beforeEach((to, from, next) => {
  const authStore = useAuthStore();

  if (to.meta.requiresAuth) {
    if (!authStore.isAuthenticated) {
      next('/');
      return;
    }

    if (to.meta.role === 'admin' && !authStore.isAdmin) {
      next('/player');
      return;
    }

    if (to.meta.role === 'player' && authStore.isAdmin) {
      next('/admin');
      return;
    }
  }

  next();
});

export default router;