<template>
  <section id="description" class="game-description">
    <div class="description-content">
      <div class="text-side">
        <h2 class="section-title">A Játékról</h2>
        <div class="description-text">
          <p>
            A <strong>Fortivex Projekt</strong> egy epikus tower defense játék, 
            ahol stratégiai gondolkodással és gyors döntésekkel kell megvédened 
            a váradat a megszámlálhatatlan ellenség hullámaitól.
          </p>
          <p>
            Építs tornyokat, fejleszd őket, és használd ki az ellenségek 
            gyengeségeit, hogy győzelmet arass! Minden pálya új kihívást és 
            különleges ellenségeket tartogat.
          </p>

          <div class="features-grid">
            <div class="feature-item">
              <div class="feature-icon">🏰</div>
              <div class="feature-info">
                <h4>Stratégiai Mélység</h4>
                <p>Építs és fejlessz különböző tornyokat</p>
              </div>
            </div>

            <div class="feature-item">
              <div class="feature-icon">🗺️</div>
              <div class="feature-info">
                <h4>Változatos Pályák</h4>
                <p>Fedezz fel egyedi környezeteket</p>
              </div>
            </div>

            <div class="feature-item">
              <div class="feature-icon">👹</div>
              <div class="feature-info">
                <h4>Sokféle Ellenség</h4>
                <p>Különböző képességekkel rendelkező ellenfelek</p>
              </div>
            </div>

            <div class="feature-item">
              <div class="feature-icon">⚡</div>
              <div class="feature-info">
                <h4>Progresszió Rendszer</h4>
                <p>Fejlődj és szerezz új képességeket</p>
              </div>
            </div>

            <div class="feature-item">
              <div class="feature-icon">🏆</div>
              <div class="feature-info">
                <h4>Teljesítmények</h4>
                <p>Oldj meg kihívásokat és szerezz jutalmakat</p>
              </div>
            </div>

            <div class="feature-item">
              <div class="feature-icon">📊</div>
              <div class="feature-info">
                <h4>Statisztikák</h4>
                <p>Kövesd nyomon fejlődésed</p>
              </div>
            </div>
          </div>

          <div class="gameplay-stats">
            <div class="stat">
              <span class="stat-number">3</span>
              <span class="stat-label">Egyedi Pálya</span>
            </div>
            <div class="stat">
              <span class="stat-number">5</span>
              <span class="stat-label">Különböző Ellenség</span>
            </div>
            <div class="stat">
              <span class="stat-number">4</span>
              <span class="stat-label">Torony Típus</span>
            </div>
            <div class="stat">
              <span class="stat-number">50+</span>
              <span class="stat-label">Teljesítmény</span>
            </div>
          </div>
        </div>
      </div>

      <div class="visual-side">
        <div class="game-preview-card">
          <div class="preview-image">
            <div class="placeholder-game">
              <span class="play-icon">▶</span>
              <p>Játék Előnézet</p>
            </div>
          </div>
          <div class="preview-info">
            <h3>Próbáld ki most!</h3>
            <p>Tapasztald meg a Fortivex izgalmát</p>
            <button class="download-button">
              <span class="button-icon">⬇️</span>
              Letöltés
            </button>
          </div>
        </div>

        <div class="info-cards">
          <div class="info-card">
            <div class="card-icon">💻</div>
            <div class="card-content">
              <h4>Platform</h4>
              <p>Windows, Mobil</p>
            </div>
          </div>

          <div class="info-card">
            <div class="card-icon">👥</div>
            <div class="card-content">
              <h4>Játékosok</h4>
              <p>Single Player</p>
            </div>
          </div>

          <div class="info-card">
            <div class="card-icon">🎮</div>
            <div class="card-content">
              <h4>Műfaj</h4>
              <p>Tower Defense, Stratégia</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup>
// No props needed for static content
</script>

<style scoped lang="scss">
.game-description {
  padding: 5rem 0;
  background: #2c1810;
}

.description-content {
  max-width: 1400px;
  margin: 0 auto;
  padding: 0 2rem;
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 4rem;
  align-items: start;

  @media (max-width: 1024px) {
    grid-template-columns: 1fr;
    gap: 3rem;
  }
}

.section-title {
  font-size: 3rem;
  color: #ffd700;
  font-family: 'Cinzel', serif;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.8);
  margin-bottom: 2rem;

  @media (max-width: 768px) {
    font-size: 2rem;
  }
}

.description-text {
  p {
    color: #f4e4c1;
    font-size: 1.1rem;
    line-height: 1.8;
    margin-bottom: 1.5rem;

    strong {
      color: #ffd700;
      font-weight: 700;
    }
  }
}

.features-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 1.5rem;
  margin: 2.5rem 0;

  @media (max-width: 640px) {
    grid-template-columns: 1fr;
  }
}

.feature-item {
  display: flex;
  gap: 1rem;
  padding: 1.5rem;
  background: #1a0f0a;
  border: 2px solid #8b4513;
  border-radius: 12px;
  transition: all 0.3s ease;

  &:hover {
    border-color: #ffd700;
    transform: translateY(-3px);
    box-shadow: 0 8px 20px rgba(255, 215, 0, 0.2);
  }

  .feature-icon {
    font-size: 2.5rem;
    flex-shrink: 0;
  }

  .feature-info {
    h4 {
      color: #ffd700;
      font-size: 1.1rem;
      margin-bottom: 0.5rem;
    }

    p {
      color: #f4e4c1;
      font-size: 0.9rem;
      line-height: 1.4;
      margin: 0;
    }
  }
}

.gameplay-stats {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 1.5rem;
  margin-top: 3rem;

  @media (max-width: 768px) {
    grid-template-columns: repeat(2, 1fr);
  }
}

.stat {
  text-align: center;
  padding: 1.5rem;
  background: linear-gradient(135deg, #1a0f0a 0%, #2c1810 100%);
  border: 2px solid #8b4513;
  border-radius: 12px;

  .stat-number {
    display: block;
    font-size: 2.5rem;
    font-weight: 700;
    color: #ffd700;
    margin-bottom: 0.5rem;
  }

  .stat-label {
    display: block;
    color: #f4e4c1;
    font-size: 0.9rem;
  }
}

.visual-side {
  display: flex;
  flex-direction: column;
  gap: 2rem;
}

.game-preview-card {
  background: #1a0f0a;
  border: 3px solid #8b4513;
  border-radius: 16px;
  overflow: hidden;
  transition: all 0.3s ease;

  &:hover {
    border-color: #ffd700;
    box-shadow: 0 10px 40px rgba(255, 215, 0, 0.3);
  }

  .preview-image {
    position: relative;
    background: linear-gradient(135deg, #2c1810 0%, #3d2517 100%);
    padding: 3rem;

    .placeholder-game {
      aspect-ratio: 16/9;
      background: #1a0f0a;
      border: 2px dashed #8b4513;
      border-radius: 12px;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 1rem;
      transition: all 0.3s ease;

      .play-icon {
        font-size: 4rem;
        color: #ffd700;
      }

      p {
        color: #f4e4c1;
        font-size: 1.2rem;
        margin: 0;
      }

      &:hover {
        border-color: #ffd700;
        background: #2c1810;
      }
    }
  }

  .preview-info {
    padding: 2rem;
    text-align: center;

    h3 {
      color: #ffd700;
      font-size: 1.5rem;
      margin-bottom: 0.5rem;
    }

    p {
      color: #f4e4c1;
      margin-bottom: 1.5rem;
    }

    .download-button {
      background: linear-gradient(135deg, #8b4513, #a0522d);
      color: #fff;
      border: 2px solid #ffd700;
      padding: 1rem 2.5rem;
      border-radius: 12px;
      font-size: 1.1rem;
      font-weight: 700;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 0.8rem;
      transition: all 0.3s ease;

      .button-icon {
        font-size: 1.3rem;
      }

      &:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 24px rgba(255, 215, 0, 0.4);
      }
    }
  }
}

.info-cards {
  display: grid;
  gap: 1rem;
}

.info-card {
  background: #1a0f0a;
  border: 2px solid #8b4513;
  border-radius: 12px;
  padding: 1.5rem;
  display: flex;
  align-items: center;
  gap: 1.5rem;
  transition: all 0.3s ease;

  &:hover {
    border-color: #ffd700;
    transform: translateX(5px);
  }

  .card-icon {
    font-size: 2.5rem;
  }

  .card-content {
    h4 {
      color: #ffd700;
      font-size: 1.1rem;
      margin-bottom: 0.3rem;
    }

    p {
      color: #f4e4c1;
      margin: 0;
      font-size: 0.95rem;
    }
  }
}
</style>