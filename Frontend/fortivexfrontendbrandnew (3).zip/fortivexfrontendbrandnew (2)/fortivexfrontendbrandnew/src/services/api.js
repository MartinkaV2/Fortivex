import axios from 'axios';

const api = axios.create({
  baseURL: 'https://localhost:7116/api',
  withCredentials: true,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor - token hozzáadása
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor - hibakezelés
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Auth endpoints (LoginController alapján)
export const authAPI = {
  login: (credentials) => api.post('/login', credentials),
  register: (userData) => api.post('/accounts', userData), // AccountsController
  logout: () => {
    localStorage.removeItem('token');
    return Promise.resolve();
  },
  getCurrentUser: () => api.get('/accounts'), // Ha van ilyen endpoint
};

// Player Stats endpoints
export const playerStatsAPI = {
  getStats: (playerId) => api.get(`/playerstats/${playerId}`),
  updateStats: (playerId, stats) => api.put(`/playerstats/${playerId}`, stats),
  getAllStats: () => api.get('/playerstats'),
};

// Player Progress endpoints
export const playerProgressAPI = {
  getProgress: (playerId) => api.get(`/playerprogress/${playerId}`),
  updateProgress: (playerId, progress) => api.put(`/playerprogress/${playerId}`, progress),
};

// Admin endpoints
export const adminAPI = {
  getAllPlayers: () => api.get('/admins/players'),
  getPlayerById: (playerId) => api.get(`/admins/players/${playerId}`),
  updatePlayer: (playerId, data) => api.put(`/admins/players/${playerId}`, data),
  deletePlayer: (playerId) => api.delete(`/admins/players/${playerId}`),
};

// Accounts endpoints
export const accountsAPI = {
  createAccount: (userData) => api.post('/accounts', userData),
  getAccount: (accountId) => api.get(`/accounts/${accountId}`),
  updateAccount: (accountId, data) => api.put(`/accounts/${accountId}`, data),
  deleteAccount: (accountId) => api.delete(`/accounts/${accountId}`),
};

export default api;