﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Price of tower or unit.
/// </summary>
public class Price : MonoBehaviour
{
    // Price in gold
    public int price;
}
