﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Waypoint of pathway.
/// </summary>
public class Waypoint : MonoBehaviour
{

}
