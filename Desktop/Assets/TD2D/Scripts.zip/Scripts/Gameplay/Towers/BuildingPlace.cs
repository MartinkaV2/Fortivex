﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Building place for towers.
/// </summary>
public class BuildingPlace : MonoBehaviour
{
	
}
