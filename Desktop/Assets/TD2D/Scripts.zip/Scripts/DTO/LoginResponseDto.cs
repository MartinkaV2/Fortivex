using UnityEngine;

[System.Serializable]
public class LoginResponseDto
{
    public string token;
    public string role;
    public string username;
    public int accountId;
}