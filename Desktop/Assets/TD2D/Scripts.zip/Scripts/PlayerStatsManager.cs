using UnityEngine;
using UnityEngine.Networking;
using System.Collections;
using System.Text;

public class PlayerStatsManager : MonoBehaviour
{
    public static PlayerStatsManager Instance;

    // Adatok
    private int myDbId; // Ez a PlayerStats tábla elsődleges kulcsa (Id), nem az AccountId!
    private int accountId;
    public int enemiesKilled; // Publikus, hogy máshonnan tudd növelni
    public int timePlayedSeconds; // Másodperc alapú számláló

    private float timerBuffer = 0f; // Törtmásodpercek gyűjtése
    private bool isTracking = false; // Csak bejelentkezés után mérjen

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else Destroy(gameObject);
    }

    void Update()
    {
        // Csak akkor számoljon, ha be vagyunk lépve és betöltöttük az adatokat
        if (isTracking)
        {
            timerBuffer += Time.deltaTime;

            // Ha eltelt 1 másodperc
            if (timerBuffer >= 1f)
            {
                timePlayedSeconds++;
                timerBuffer -= 1f;
            }
        }
    }

    /// <summary>
    /// Login után hívjuk meg: Beállítja az ID-t és letölti a régi statisztikát.
    /// </summary>
    public void InitAndLoadStats(int accId)
    {
        accountId = accId;
        StartCoroutine(GetStatsAndStartTracking());
    }

    /// <summary>
    /// 1. Letölti a szerverről a jelenlegi állást (hogy ne nullázza le a régi perceket)
    /// </summary>
    IEnumerator GetStatsAndStartTracking()
    {
        string url = $"https://fortivex.runasp.net/api/PlayerStats";
        
        UnityWebRequest req = UnityWebRequest.Get(url);
        req.SetRequestHeader("Authorization", "Bearer " + APIManager.Instance.Token);

        yield return req.SendWebRequest();

        if (req.result != UnityWebRequest.Result.Success)
        {
            Debug.LogError("STATS LOAD ERROR: " + req.error);
            // Ha hiba van, akkor is elindíthatjuk 0-ról, vagy újrapróbálhatjuk
            // Itt most feltételezzük, hogy létre kell hozni (lásd APIManager Create logika), 
            // de egyszerűség kedvéért most csak logolunk.
        }
        else
        {
            // JSON feldolgozás
            string json = req.downloadHandler.text;
            PlayerStatsDto[] allStats = JsonHelper.FromJson<PlayerStatsDto>(json);
            
            bool found = false;
            foreach(var stat in allStats)
            {
                if(stat.accountId == accountId)
                {
                    // MEGTALÁLTUK A SZERVEREN LÉVŐ ADATOKAT
                    myDbId = stat.id;
                    enemiesKilled = stat.enemiesKilled;
                    timePlayedSeconds = stat.timePlayed;
                    found = true;
                    Debug.Log($"Stats betöltve! Eddigi játékidő: {timePlayedSeconds} mp, Kills: {enemiesKilled}");
                    break;
                }
            }

            if (!found)
            {
                Debug.LogWarning("Nincs még statisztika, újat kezdünk 0-ról.");
                // Itt érdemes lenne meghívni egy Create-et, ha még nincs, 
                // de a te APIManageredben a Kill regisztrációnál van auto-create.
            }

            // Mérés indítása
            isTracking = true;
            
            // Opcionális: Automata mentés percenként
            StartCoroutine(AutoSaveRoutine());
        }
    }

    /// <summary>
    /// Automatikus mentés percenként, hogy crash esetén se vesszen el sok adat
    /// </summary>
    IEnumerator AutoSaveRoutine()
    {
        while (isTracking)
        {
            yield return new WaitForSeconds(60f);
            SaveStats();
        }
    }

    public void AddKill()
    {
        enemiesKilled++;
        // Killeknél azonnal menthetünk, vagy várhatunk az auto-save-re
    }

    /// <summary>
    /// Adatok feltöltése (PUT)
    /// </summary>
    public void SaveStats()
    {
        if (!isTracking || myDbId == 0) return; // Ha nincs ID, nem tudunk PUT-olni (UPDATE-elni)

        StartCoroutine(PutStats());
    }

    IEnumerator PutStats()
    {
        // Az aktuális helyi értékeket küldjük fel
        PlayerStatsDto dto = new PlayerStatsDto
        {
            id = myDbId, // Fontos: vissza kell küldeni az ID-t is
            accountId = accountId,
            enemiesKilled = enemiesKilled,
            timePlayed = timePlayedSeconds
        };

        string json = JsonUtility.ToJson(dto);
        byte[] body = Encoding.UTF8.GetBytes(json);

        // A PUT URL-nek tartalmaznia kell az ID-t a REST konvenció szerint
        string url = $"https://fortivex.runasp.net/api/PlayerStats/{myDbId}";

        UnityWebRequest req = new UnityWebRequest(url, "PUT");
        req.uploadHandler = new UploadHandlerRaw(body);
        req.downloadHandler = new DownloadHandlerBuffer();

        req.SetRequestHeader("Content-Type", "application/json");
        req.SetRequestHeader("Authorization", "Bearer " + APIManager.Instance.Token);

        yield return req.SendWebRequest();

        if (req.result != UnityWebRequest.Result.Success)
            Debug.LogError("STATS SAVE ERROR: " + req.error + " | " + req.downloadHandler.text);
        else
            Debug.Log($"STATS SAVED (Time: {timePlayedSeconds})");
    }
    
    // Ha kilép a játékból, mentsünk
    void OnApplicationQuit()
    {
        SaveStats();
    }
}