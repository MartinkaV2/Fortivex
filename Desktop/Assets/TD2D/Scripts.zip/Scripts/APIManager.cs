using System;
using System.Collections;
// using System.Diagnostics;  <-- EZT T�R�LD KI!
using System.Text;
using UnityEngine;
using UnityEngine.Networking;

public class APIManager : MonoBehaviour
{
    public static APIManager Instance;

    private string baseUrl = "http://localhost:5105/api";

    void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
    }

    // REGISZTR�CI�
    public IEnumerator Register(string username, string email, string password, Action<string> onSuccess, Action<string> onError)
    {
        string url = baseUrl + "/Accounts/register";

        RegisterRequest requestData = new RegisterRequest
        {
            userName = username,
            email = email,
            passwordHash = password,
            role = "Player"
        };

        string jsonData = JsonUtility.ToJson(requestData);
        Debug.Log("Regisztr�ci� k�ld�se: " + jsonData);

        yield return StartCoroutine(PostRequest(url, jsonData, onSuccess, onError));
    }

    // BEJELENTKEZ�S
    public IEnumerator Login(string username, string password, Action<string> onSuccess, Action<string> onError)
    {
        string url = baseUrl + "/Accounts/login";

        LoginRequest requestData = new LoginRequest
        {
            userName = username,
            passwordHash = password
        };

        string jsonData = JsonUtility.ToJson(requestData);
        Debug.Log("Login k�ld�se: " + jsonData);

        yield return StartCoroutine(PostRequest(url, jsonData, onSuccess, onError));
    }

    private IEnumerator PostRequest(string url, string jsonData, Action<string> onSuccess, Action<string> onError)
    {
        using (UnityWebRequest request = new UnityWebRequest(url, "POST"))
        {
            byte[] bodyRaw = Encoding.UTF8.GetBytes(jsonData);
            request.uploadHandler = new UploadHandlerRaw(bodyRaw);
            request.downloadHandler = new DownloadHandlerBuffer();
            request.SetRequestHeader("Content-Type", "application/json");

            yield return request.SendWebRequest();

            if (request.result == UnityWebRequest.Result.ConnectionError || request.result == UnityWebRequest.Result.ProtocolError)
            {
                string errorMsg = request.error;
                if (request.downloadHandler != null)
                    errorMsg += " | Backend v�lasz: " + request.downloadHandler.text;

                onError?.Invoke(errorMsg);
            }
            else
            {
                onSuccess?.Invoke(request.downloadHandler.text);
            }
        }
    }
}