﻿namespace FortivexAPI.Dtos
{
    public class AccountDto
    {
        public int Id { get; set; }
        public string Username { get; set; } = null!;
        public string? Email { get; set; } = null!;
        public string PasswordHash { get; internal set; } = null!;
    }
}
