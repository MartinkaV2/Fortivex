﻿using FortivexAPI.Dtos;
using FortivexAPI.Helpers;
using FortivexAPI.Models;
using FortivexAPI.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;


namespace FortivexAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly UserService _userService;
        private readonly JwtHelper _jwtHelper;
        private readonly string _key;
        private readonly string Key = "EzEgySajatSzuperTitkosKulcs123!";
        private char[] key;
        private object config;

        public UsersController(UserService userService, JwtHelper jwtHelper)
            {
            _userService = userService;
            _jwtHelper = jwtHelper;
            Key = config["Jwt:Key"];
        }

        [HttpPut("login")]
        public async Task<IActionResult> Login([FromBody] LoginRequestDto loginRequest)
        {
            var user = await _userService.GetUserAsync(loginRequest.UserName, loginRequest.PasswordHash);
            if (user == null)
                return Unauthorized("Hibás bejelentkezés!");

            if (string.IsNullOrEmpty(Key))
                throw new Exception("JWT kulcs nincs beállítva!");
            var keyBytes = Encoding.UTF8.GetBytes(Key);

            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.UTF8.GetBytes(Key);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[]
                {
            // Ide kell bemásolni:
            new Claim(ClaimTypes.Name, user.Username),
            new Claim(ClaimTypes.Role, user.Role)
        }),
                Expires = DateTime.UtcNow.AddHours(1),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            var jwt = tokenHandler.WriteToken(token);

            return Ok(new LoginResponseDto { Token = jwt });
        }

        [HttpGet("me")]
        [Authorize(Roles = "User,Admin")]
        public IActionResult GetMyData()
        {
            return Ok($"Bejelentkezve mint: {User.Identity?.Name}");
        }

        [HttpGet("admin")]
        [Authorize(Roles = "Admin")]
        public IActionResult GetAdminData()
        {
            return Ok("Csak az Admin látja ezt az adatot!");
        }

        [HttpPut("register")]
        public async Task<IActionResult> Register([FromBody] RegisterRequestDto registerRequest)
        {
            if (await _userService.GetUserByUsernameAsync(registerRequest.UserName) is User existingUser)
                return BadRequest("A felhasználónév már foglalt.");
            var newUser = new User
            {
                Username = registerRequest.UserName,
                PasswordHash = registerRequest.PasswordHash,
                Email = registerRequest.Email,
                Role = registerRequest.Role
            };
            await _userService.CreateUserAsync(newUser);
            return Ok("Sikeres regisztráció!");
        }



    }
}
