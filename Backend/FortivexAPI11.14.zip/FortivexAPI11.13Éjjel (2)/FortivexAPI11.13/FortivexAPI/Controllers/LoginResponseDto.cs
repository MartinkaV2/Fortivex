﻿namespace FortivexAPI.Controllers
{
    internal class LoginResponseDto
    {
        public string Token { get; set; }
    }
}