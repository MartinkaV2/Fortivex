﻿using FortivexAPI.Data;
using FortivexAPI.Helpers;
using FortivexAPI.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.Text;

internal class Program
{
    private static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        // ✅ 1️⃣ Engedélyezett frontend origin
        var frontendUrl = "http://localhost:5173"; // <-- VITE alapértelmezett port

        // ✅ 2️⃣ CORS beállítás
        builder.Services.AddCors(options =>
        {
            options.AddPolicy("AllowFrontend", policy =>
            {
                policy.WithOrigins(frontendUrl)
                      .AllowAnyHeader()
                      .AllowAnyMethod()
                      .AllowCredentials();
            });
        });

        // ✅ 3️⃣ Egyéb service-ek
        builder.Services.AddDbContext<FortivexContext>(options =>
            options.UseMySQL(builder.Configuration.GetConnectionString("DefaultConnection")!));

        builder.Services.AddScoped<UserService>();
        builder.Services.AddScoped<JwtHelper>();
        builder.Services.AddControllers();
        builder.Services.AddEndpointsApiExplorer();
        builder.Services.AddSwaggerGen();

        // ✅ 4️⃣ JWT auth
        var key = builder.Configuration["Jwt:Key"] ?? "YourSuperSecretKeyForDevelopment12345";

        builder.Services.AddAuthentication(options =>
        {
            options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
            options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
        })
        .AddJwtBearer(options =>
        {
            options.TokenValidationParameters = new TokenValidationParameters
            {
                ValidateIssuer = false,
                ValidateAudience = false,
                ValidateLifetime = true,
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key)),
                ClockSkew = TimeSpan.Zero
            };
        });

        builder.Services.AddAuthorization();

        var app = builder.Build();

        // ✅ --- MIDDLEWARE SORREND ---
        if (app.Environment.IsDevelopment())
        {
            app.UseSwagger();
            app.UseSwaggerUI();
        }

        app.UseHttpsRedirection();

        app.UseRouting();

        // 💡 CORS mindig az AUTH előtt!
        app.UseCors("AllowFrontend");

        app.UseAuthentication();
        app.UseAuthorization();

        app.MapControllers();

        app.Run();
    }
}
